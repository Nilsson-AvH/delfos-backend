import mongoose from 'mongoose';

const Schema = mongoose.Schema;

/**
 * SystemCompany Model (Configuración del Tenant / Dueño del Software)
 * * Singleton: Solo debe existir 1 documento de estos en toda la colección.
 */
const SystemCompanySchema = new Schema({

    // 1. Identidad Corporativa (Colombianizada 🇨🇴)
    // ----------------------------------------------------------------
    companyName: { 
        type: String, 
        required: [true, "El nombre de la empresa es obligatorio"], 
        trim: true,
        uppercase: true 
    },
    nit: { 
        type: String, 
        required: [true, "El NIT es obligatorio"], 
        trim: true 
    },
    
    // Ubicación Geográfica
    department: { 
        type: String, 
        required: [true, "El departamento es obligatorio"], // Ej: Cundinamarca
        trim: true 
    },
    city: { 
        type: String, 
        required: [true, "La ciudad/municipio es obligatoria"], // Ej: Sopó
        trim: true 
    },
    address: { 
        type: String, 
        required: [true, "La dirección es obligatoria"], 
        trim: true 
    },
    
    phones: [{ type: String }],
    email: { type: String, lowercase: true, trim: true },
    website: { type: String, trim: true },

    // Representante Legal (Para firmas automáticas)
    legalRepresentative: {
        name: { type: String, required: true, uppercase: true },
        role: { type: String, default: 'GERENTE GENERAL', uppercase: true }
    },

    // 2. Branding (Logos y Firmas en Cloudinary)
    // ----------------------------------------------------------------
    logoUrl: { type: String },           // Logo
    logoHeaderUrl: { type: String },     // Logo del encabezado
    logoFooterUrl: { type: String },     // Logo del pie de página
    watermarkUrl: { type: String },      // Escudo de fondo
    qrCodeUrl: { type: String },         // QR Code de la empresa
    letterHeadUrl: { type: String },     // Encabezado de carta
    signatureUrl: { type: String },      // Firma del rep. legal por defecto

    // 3. CONTROL DE SUSCRIPCIÓN (SaaS Mode) 🛑
    // ----------------------------------------------------------------
    // Estos campos deberían ser "ReadOnly" para el usuario normal, 
    // solo editables por ti (Root) vía base de datos o endpoint especial.
    licenseKey: { type: String, select: false }, 
    
    subscriptionStatus: { 
        type: String, 
        enum: ['active', 'suspended', 'grace_period', 'pending_approval'], // <--- Estado de la suscripción
        default: 'pending_approval' // <--- Inactiva por seguridad pero en demo_trial se activa automáticamente
    },

    // 👇👇👇 ¡PLAN DEL CLIENTE! 👇👇👇
    planType: {
        type: String,
        enum: ['demo_trial', 'basic', 'pro', 'enterprise'], // Lista de planes válidos
        default: 'demo_trial'
    },
    // 👆👆👆 ----------------------------- 👆👆👆
    
    validUntil: { 
        type: Date, 
        required: true,
        // Por defecto: 30 días desde hoy para demo_trial y enamorar al cliente
        default: Date.now 
    },

    // 👇👇👇 EL CONTROL DE SEDES 👇👇👇
    
    // LIMITADORES DEL PLAN (Lo que le vendes al cliente)
    maxBranchesAllowed: { 
        type: Number, 
        default: 1, // Plan Demo/Básico: Solo 1 sede (la principal)
        required: true  
    },
    
    maxUsersAllowed: { 
        type: Number, 
        default: 5, // Plan Demo/Básico: 5 usuarios
        required: true
    }

}, {
    timestamps: true,
    versionKey: false
});

const SystemCompany = mongoose.model('SystemCompany', SystemCompanySchema);

export default SystemCompany;