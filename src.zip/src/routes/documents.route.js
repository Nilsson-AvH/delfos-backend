import { Router } from "express";
import {
    createDocument,
    deleteDocumentById,
    getAllDocuments,
    getDocumentById,
    updateDocumentById,
    getDocumentsByUser // <--- 1. IMPORTANTE: Importamos la nueva función
} from "../controllers/document.controller.js";
import authenticationUser from "../middlewares/authentication.middleware.js";
import authorizationUser from "../middlewares/authorization.middleware.js";
// 1. IMPORTAR EL MIDDLEWARE DE LA NUBE CLOUDINARY ☁️
import uploadCloud from "../config/cloudinary.config.js";

const router = Router();

// Rutas base: /api/v1/documents

// 2. CLOUDINARY: INYECTARLO EN EL POST
// 'file' es la llave que usaremos en Postman
router.post(`/`, [authenticationUser, authorizationUser, uploadCloud.single('file')], createDocument); //http://localhost:3000/api/v1/documents

// Listar Documentos
router.get(`/`, [authenticationUser, authorizationUser], getAllDocuments); //http://localhost:3000/api/v1/documents

// 3. RUTA IMPORTANTE: Obtener carpeta de un empleado especifico
// OJO: Esta ruta debe ir ANTES de `/:id` para que Express no confunda "user" con un ID.
router.get(`/user/:userId`, [authenticationUser, authorizationUser], getDocumentsByUser); //http://localhost:3000/api/v1/documents/user/:userId

// Operaciones por ID de Documento
// NOTA: Cambié ':idDocument' por ':id' para que coincida con el controlador (req.params.id)
// Obtener documentos por ID
router.get(`/:id`, [authenticationUser, authorizationUser], getDocumentById); //http://localhost:3000/api/v1/documents/:id

// Actualizar documentos por ID
router.patch(`/:id`, [authenticationUser, authorizationUser], updateDocumentById); //http://localhost:3000/api/v1/documents/:id

// Eliminar documentos por ID
router.delete(`/:id`, [authenticationUser, authorizationUser], deleteDocumentById); //http://localhost:3000/api/v1/documents/:id

export default router;